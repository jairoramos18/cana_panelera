package gestion;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

public class GestionArchivo {
    private final String path = "src/archivos/";
    private File archivo;
    private PrintWriter escribir;
    private Scanner leer;
    private String nombreArchivo;
    
    public GestionArchivo(String nombreArchivo){
        this.nombreArchivo = nombreArchivo;
        archivo = new File(path+nombreArchivo);
    }

    public void escribirArchivo(String datos){
        try{
            escribir = new PrintWriter(archivo);
            escribir.println(datos);
        }catch(IOException e){
            System.err.println("Ocurrio un error en la escritura. "+e);
        }finally{
            escribir.close();
        }
         
        
    }
    public ArrayList<String> leerArchivo(){
        ArrayList<String> datosLeidos = new ArrayList<>();
        try{
           leer = new Scanner(archivo);
           while(leer.hasNext()){
              datosLeidos.add(leer.next());
           }
        }catch(IOException e){
            System.err.println("Ocurrio un error en la lectura. "+e);     
        }finally{
            if(archivo.exists()){
                leer.close();
            }
            
        }
        return datosLeidos;
    }

    public void infoArchivo(){
        System.out.println("Informacion del archivo "+nombreArchivo);
        System.out.println("Tamaño: "+archivo.length()+" bytes");
        System.out.println("Ultima modificacion: "
                                    +new Date(archivo.lastModified()));
        System.out.println("Ubicacion: "+archivo.getAbsolutePath());
    }
}
