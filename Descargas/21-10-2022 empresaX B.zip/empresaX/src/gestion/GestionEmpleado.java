package gestion;

import java.util.Scanner;
import nomina.Empleado;
import java.util.ArrayList;
import java.util.InputMismatchException;

public class GestionEmpleado {

    private Scanner sc;
    private Empleado empleado;
    private ArrayList<Empleado> listaEmpleados;
    private GestionArchivo gestionArchivo;

    public GestionEmpleado() {
        sc = new Scanner(System.in);
        listaEmpleados = new ArrayList<>();
        gestionArchivo = new GestionArchivo("empleados.txt");
        leerEmpleadosArchivo();
    }

    public void menu() {
        int opcion;
        boolean salir = false;
        do {
            System.out.println("\nMENU DE GESTION DE EMPLEADOS\n"
                    + "1-Agregar\n"
                    + "2-Modificar\n"
                    + "3-Eliminar\n"
                    + "4-Visualizar\n"
                    + "5-Buscar\n"
                    + "6-Salir\n");
            try{
                System.out.println("Ingrese una opción");
                opcion = sc.nextInt();
                switch (opcion) {
                    case 1:
                        agregarEmpleado();
                        break;
                    case 2:
                        modificarEmpleado();
                        break;
                    case 3:
                        eliminarEmpleado();
                        break;
                    case 4:
                        visualizarEmpleados();
                        break;
                    case 5:
                        buscarEmpleado();
                        break;
                    case 6:
                        salir = true;
                        break;
                    default:
                        System.out.println("Opcion invalida. intente de nuevo");
                }
            }catch(InputMismatchException i){
                System.err.println("El tipo de dato ingresado no es correcto ");
                sc.next();
            }catch(Exception e){
                System.err.println("Ocurrio un error inesperado");
            }            

        } while (salir == false);
        System.out.println("Gracias por utilizar el programa!!");
    }

    private void agregarEmpleado() {
        System.out.println("AGREGAR EMPLEADOS");
        String nombre, codigo;
        int horas;
        double valor;
        try{
            System.out.println("Ingrese el codigo del empleado");
            codigo = sc.next();
            System.out.println("Ingrese el nombre del empleado");
            nombre = sc.next();
            System.out.println("Ingrese las horas trabajadas");
            horas = sc.nextInt();
            System.out.println("Ingrese el valor X hora");
            valor = sc.nextDouble();
            empleado = new Empleado(codigo, nombre, horas, valor);
            listaEmpleados.add(empleado);
            empleado.calcularSueldo();
            gestionArchivo.escribirArchivo(empleado.toString());
        }catch(InputMismatchException i){
            System.err.println("El tipo de dato ingresado no es correcto ");
            sc.next();
            agregarEmpleado();
        }        
    }

    private void modificarEmpleado() {
       int posicion = buscarEmpleado();
       if(posicion >= 0){//si encontro el objeto retorna la posicion
           try{
                empleado = listaEmpleados.get(posicion);
                System.out.println("Ingrese el nuevo nombre");
                empleado.setNombreEmp(sc.next());
                System.out.println("Ingrese las nuevas horas");
                empleado.setHorasTrab(sc.nextInt());
                System.out.println("Ingrese el nuevo valor de la hora");
                empleado.setvalorHora(sc.nextDouble());
                empleado.calcularSueldo();
                System.out.println("Se modifico el empleado con codigo "+empleado.getCodigo());   
           }catch(InputMismatchException i){
                System.err.println("El tipo de dato ingresado no es correcto ");
                sc.next();
                modificarEmpleado();
            } 
           
       }
    }

    private void eliminarEmpleado() {
        System.out.println("ELIMINAR EMPLEADO");
        int posicion = buscarEmpleado();
        if(posicion >= 0){//si encontro el objeto retorna la posicion
            listaEmpleados.remove(posicion);
            System.out.println("Se eliminó el empleado");
        }
    }

    private void visualizarEmpleados() {
        //visualizamos valores utilizando el toString
        System.out.println("Listado de empleados");
        if (!listaEmpleados.isEmpty()) {
            System.out.println("Codigo | Nombre  | horas | valor | sueldo");
            for(Empleado empleado1: listaEmpleados){
                System.out.println(empleado1);
            }
        } else {
            System.out.println("No hay empleados registrados");
        }
    }

    private int buscarEmpleado() {
        System.out.println("BUSCAR EMPLEADO");
        if (!listaEmpleados.isEmpty()) {
            String codigo;
            System.out.println("Ingrese el codigo del empleado");
            codigo = sc.next();
            for(Empleado empleado1: listaEmpleados){
                if(codigo.equals(empleado1.getCodigo())){
                    System.out.println(empleado1);
                    return listaEmpleados.indexOf(empleado1);//retorna la posicion del objeto
                }
            }
        }
        else {
            System.out.println("No hay empleados registrados");
        }
        System.out.println("No se encontro el empleado");
        return -1;//retorna un valor negativo sino encuentra el objeto
    }

    public void leerEmpleadosArchivo(){
        ArrayList<String> empleadosArchivo = gestionArchivo.leerArchivo();
        for(String datos: empleadosArchivo){
            
            String datosEmpleado[] = datos.split("\\|");
System.out.println(datosEmpleado[0]);
            empleado = new Empleado(datosEmpleado[0],
                                    datosEmpleado[1],
                                    Integer.parseInt(datosEmpleado[2]),
                                    Double.parseDouble(datosEmpleado[3]));
            listaEmpleados.add(empleado);
        }
    }
}
