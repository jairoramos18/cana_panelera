package nomina;

public class Empleado {
    private String codigo;
    private String nombreEmp;
    private int horasTrab;
    private double valorHora;
    private double sueldo;

    public Empleado(String codigo, String nombreEmp, int horasTrab, double valorHora) {
        this.nombreEmp = nombreEmp;
        this.horasTrab = horasTrab;
        this.valorHora = valorHora;
        this.codigo = codigo;
    }    
    
    public void setNombreEmp(String nombreEmp){
        this.nombreEmp = nombreEmp;
    }
    
    public void setHorasTrab(int horasTrab){
        this.horasTrab = horasTrab;
    }
    
    public void setvalorHora(double valorHora){
        this.valorHora = valorHora;
    }
    
    public void calcularSueldo(){
        sueldo = horasTrab * valorHora;
    }
    
    public String getNombreEmp(){
        return nombreEmp;
    }
    
    public double getSueldo(){
        return sueldo;
    }

    public String getCodigo() {
        return codigo;
    }
    
    

    @Override
    public String toString(){
         return   codigo+"|"
                 +nombreEmp+"|"
                 +horasTrab+"|"
                 +valorHora+"|"
                 +sueldo;
    }
}
