package empresax;

import gestion.GestionEmpleado;

public class Principal {

    public static void main(String[] args) {
        GestionEmpleado gestion = new GestionEmpleado();     
        gestion.menu();
    }
    
}
