package gestion;
import java.util.ArrayList;
import java.util.Scanner;
import miembros.*;

public class GestionPersona {
    private Scanner sc;
    private Persona persona;
    private ArrayList<Persona> listaPersonas;
    
    public GestionPersona(){
        sc = new Scanner(System.in);
        listaPersonas = new ArrayList<>();
    }
    
    public void menu(){
        boolean salir = false;
        int opcion;
        do{
            System.out.println("GESTION PERSONAS");
            System.out.println("1-AGREGAR"
                           + "\n2-MODIFICAR"
                           + "\n3-ELIMINAR"
                           + "\n4-BUSCAR"
                           + "\n5-VISUALIZAR"
                           + "\n6-SALIR");
            System.out.println("Ingrese la opcion");
            opcion = sc.nextInt();
            switch(opcion){
                case 1: agregar();
                break;
                case 2: modificar();
                break;
                case 3: eliminar();
                break;
                case 4: buscar();
                break;
                case 5:visualizar();
                break;
                case 6: salir=true;
                break;
                default: System.out.println("Ingrese una opcion valida");                    
            }
        }while(salir == false);
        System.out.println("Gracias por utilizar el programa");
    }

    private void agregar() {
        System.out.println("AGREGAR PERSONA");
        
        System.out.println("Ingrese que tipo de persona desea agregar"
                         + "1-Estudiante o 2-Docente");
        int tipo = sc.nextInt();
        if(!verificaTipoPersona(tipo)){//valida el tipo de persona
            System.out.println("El tipo de persona no es valido");
            agregar();
        }
        
        String nombre,direccion,fechaNacimiento,documento;
        char sexo;
        System.out.println("Ingrese el nombre");
        nombre = sc.next();
        System.out.println("Ingrese la direccion");
        direccion = sc.next();
        System.out.println("Ingrese la fecha de nacimiento");
        fechaNacimiento = sc.next();
        System.out.println("Ingrese el documento");
        documento = sc.next();
        System.out.println("Ingrese el sexo. M/F");
        sexo=sc.next().charAt(0);
        
        if(tipo == 1){
            System.out.println("Ingrese la carrera");
            String carrera = sc.next();
            System.out.println("Ingrese el promedio");
            double promedio = sc.nextDouble();
            persona = new Estudiante(carrera, promedio,nombre,direccion,
            fechaNacimiento, sexo, documento);
        }
        else if(tipo == 2){
            System.out.println("Ingrese el salario");
            double salario = sc.nextDouble();
            System.out.println("Ingrese el titulo");
            String titulo = sc.next();
            persona = new Docente(salario, titulo,nombre,direccion,
            fechaNacimiento, sexo, documento);
        }
        listaPersonas.add(persona);
        
    }
    
    private boolean verificaTipoPersona(int tipo){
        if(tipo == 1 || tipo == 2){//1-estudiante 2-docente
            return true;
        }
        else{
            return false;
        }
    }

    private void modificar() {
        
    }

    private void eliminar() {
     
    }

    private int buscar() {
        System.out.println("BUSCAR PERSONAS");
        System.out.println("Ingrese el documento");
        String documento = sc.next();
        for(Persona persona: listaPersonas){
            if(documento.equals(persona.getDocumento())){
                System.out.println(persona);
                return listaPersonas.indexOf(persona);
            }
        }
        System.out.println("No se encontro la persona");
        return -1;
    }

    private void visualizar() {
      
    }
}







