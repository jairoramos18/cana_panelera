package miembros;

public class Estudiante extends Persona{
    private String carrera;
    private double promedio;

    public Estudiante(String carrera, double promedio, String nombre, String direccion, 
            String fechaNacimiento, char sexo, String documento) {
        super(nombre, direccion, fechaNacimiento, sexo, documento);
        this.carrera = carrera;
        this.promedio = promedio;
    }

    @Override
    public String toString() {
        return super.toString()+"\nEstudiante{" + "carrera=" + carrera + ", promedio=" + promedio + '}';
    }

    public String getCarrera() {
        return carrera;
    }

    public void setCarrera(String carrera) {
        this.carrera = carrera;
    }

    public double getPromedio() {
        return promedio;
    }

    public void setPromedio(double promedio) {
        this.promedio = promedio;
    }
    
    
    
}
