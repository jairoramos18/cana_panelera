package miembros;

public class Docente extends Persona{
    private double salario;
    private String titulo;

    public Docente(double salario, String titulo, String nombre, String direccion, 
            String fechaNacimiento, char sexo, String documento) {
        super(nombre, direccion, fechaNacimiento, sexo, documento);
        this.salario = salario;
        this.titulo = titulo;
    }

    @Override
    public String toString() {
        return super.toString()+"\nDocente{" + "salario=" + salario + ", titulo=" + titulo + '}';
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }
    
    
}
